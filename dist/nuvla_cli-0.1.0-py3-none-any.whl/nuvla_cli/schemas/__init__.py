from .nuvla_schema import NuvlaSchema, CLIConstants

cli_constants: CLIConstants = CLIConstants()
