from nuvla_cli import app_cli
app_cli()
