# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nuvla_cli',
 'nuvla_cli.commands',
 'nuvla_cli.common',
 'nuvla_cli.nuvlaio',
 'nuvla_cli.schemas']

package_data = \
{'': ['*']}

install_requires = \
['Shapely>=1.8.4,<2.0.0',
 'docker>=6.0.0,<7.0.0',
 'fabric>=2.7.1,<3.0.0',
 'nuvla-api>=3.0.8,<4.0.0',
 'pydantic>=1.10.0,<2.0.0',
 'pyshp>=2.3.1,<3.0.0',
 'toml>=0.10.2,<0.11.0',
 'typer[all]>=0.6.1,<0.7.0']

entry_points = \
{'console_scripts': ['nuvla-cli = nuvla_cli.__main__:app_cli']}

setup_kwargs = {
    'name': 'nuvla-cli',
    'version': '0.1.0',
    'description': '',
    'long_description': '# CLI Manual\n\nInstall python3 Requirements \n```shell\n$ pip install -r requirements.txt\n```\n\nCLI Base Commands\n```shell\n$ ./nuvla_cli --help\n\nCommands:\n  clear                 Clears all the Edges instances for the user created by the CLI                                                                                                                       \n  create                                                                                                                                                                                                     \n  list                                                                                                                                                                                                       \n  locate                                                                                                                                                                                                     \n  login                 Login to Nuvla. The login is persistent and only with API keys                                                                                                                       \n  logout                \n  remove                                                                                                                                                                                                      \n  start                                                                                                                                                                                                       \n  stop                                                                                                                                                                                                        \n  user             \n```\n\n',
    'author': 'Nacho',
    'author_email': 'nacho@sixsq.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
