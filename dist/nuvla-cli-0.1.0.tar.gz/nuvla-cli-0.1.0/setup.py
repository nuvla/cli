# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nuvla_cli',
 'nuvla_cli.commands',
 'nuvla_cli.common',
 'nuvla_cli.nuvlaio',
 'nuvla_cli.schemas']

package_data = \
{'': ['*']}

install_requires = \
['Shapely>=1.8.4,<2.0.0',
 'docker>=6.0.0,<7.0.0',
 'fabric>=2.7.1,<3.0.0',
 'nuvla-api>=3.0.8,<4.0.0',
 'pydantic>=1.10.0,<2.0.0',
 'pyshp>=2.3.1,<3.0.0',
 'toml>=0.10.2,<0.11.0',
 'typer[all]>=0.6.1,<0.7.0']

entry_points = \
{'console_scripts': ['nuvla-cli = nuvla_cli.__main__:app_cli']}

setup_kwargs = {
    'name': 'nuvla-cli',
    'version': '0.1.0',
    'description': '',
    'long_description': '# CLI Manual\n\nInstall python3 Requirements \n```shell\n$ pip install -r requirements.txt\n```\n\nCLI Base Commands\n```shell\n$ ./nuvla_cli --help\n\nCommands:\n  edge\n  device\n  login\n  logout\n  clear\n  version\n```\n\nEdge commands\n```shell\n$ ./nuvla_cli edge --help\n\nOptions:\n  --help  Show this message and exit.\n\nCommands:\n  create\n  list\n  remove\n  start\n  stop\n```\n\nedge create options\n```shell\nOptions:\n  --name TEXT\n  --description TEXT\n  --count INTEGER       [default: 1]\n  --dummy / --no-dummy  [default: no-dummy]\n  --fleet-name TEXT     [default: Testing]\n  --help                Show this message and exit.\n```\nIMPORTANT: Name and description are ignored at this moment. Base name will be [FleetName] NuvlaEdge_#\n\n## Basics\n### Create  a single NuvlaEdge\n```shell\n$ ./nuvla_cli edge create\n```\nDummy Nuvlaedge \n```shell\n$ ./nuvla_cli edge create --dummy\n```\n\n### Create a fleet\n```shell\n$ ./nuvla_cli edge create --count 10 --fleet-name MyFleet \n```\nDummy NuvlaEdge fleet\n```shell\n$ ./nuvla_cli edge create --count 10 --fleet-name MyFleet --dummy\n```\n\n### Start NuvlaEdges in the same device\nThis command will start all the non-dummy NuvlaEdges created in this device\n```shell\n$ ./nuvla_cli edge start <nuvlaedge_uuid>\n```\n\n### Remove NuvlaEdges from Nuvla\nReal and dummy NEE are removed in different commands\n```shell\n$ ./nuvla_cli edge remove <nuvlaedge_uuid>\n```\n\n## GeoLocation\n\n### Create a GeoLocated Edge (By Country)\nThis command will:\\\n    1. Create 10 Edge instances in Nuvla.io\\\n    2. Locate those Edges withing the selected country\\\n    3. Start those NuvlaEdges (If not dummy)\\\n\n     \n```shell\n$ ./nuvla_cli fleet create MyFleetName --count 10 --dummy\n$ ./nuvla_cli fleet glocate --name MyFleetName --country France\n$ ./nuvla_cli fleet start MyFleetName\n```\n',
    'author': 'Nacho',
    'author_email': 'nacho@sixsq.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
